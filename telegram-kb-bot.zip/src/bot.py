"""
Bot de Telegram que responde preguntas usando la BdC en /kb + un LLM
configurado en .env. Pensado para correr en background de forma continua
(ver deploy/telegram-bot.service o deploy/Dockerfile).
"""

import logging
import os
import threading
import time

from dotenv import load_dotenv
from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, ContextTypes, filters

import llm_client
import retrieval

load_dotenv()

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger("telegram-kb-bot")

TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
KB_REPO_URL = os.getenv("KB_REPO_URL", "").strip()
KB_PULL_INTERVAL_SECONDS = int(os.getenv("KB_PULL_INTERVAL_SECONDS", "300"))

SYSTEM_PROMPT = (
    "Eres un asistente que responde preguntas únicamente a partir del "
    "contexto proporcionado, extraído de la Base de Conocimiento. "
    "Si la respuesta no está en el contexto, dilo explícitamente en "
    "lugar de inventar información."
)


def sync_kb_once():
    """Clona la BdC si no existe, o la actualiza con git pull si ya existe.
    Se llama una vez de forma síncrona ANTES de arrancar el bot, para no
    responder preguntas sin tener todavía la BdC disponible."""
    if not KB_REPO_URL:
        return
    import git  # GitPython

    kb_path = os.getenv("KB_PATH", "./kb")
    try:
        if os.path.exists(os.path.join(kb_path, ".git")):
            git.Repo(kb_path).remotes.origin.pull()
            logger.info("BdC actualizada (git pull) correctamente.")
        else:
            git.Repo.clone_from(KB_REPO_URL, kb_path)
            logger.info("BdC clonada por primera vez en %s.", kb_path)
    except Exception as e:
        logger.warning(f"No se pudo sincronizar la BdC: {e}")


def pull_kb_loop():
    """Hilo en background: repite sync_kb_once() cada N segundos."""
    if not KB_REPO_URL:
        return
    while True:
        time.sleep(KB_PULL_INTERVAL_SECONDS)
        sync_kb_once()


async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    question = update.message.text
    logger.info(f"Pregunta recibida: {question!r}")

    context_text = retrieval.get_relevant_context(question)

    if context_text:
        prompt = (
            f"Contexto de la Base de Conocimiento:\n{context_text}\n\n"
            f"Pregunta del usuario: {question}\n\n"
            f"Responde solo con información del contexto anterior."
        )
    else:
        prompt = (
            f"Pregunta del usuario: {question}\n\n"
            f"No se ha encontrado contexto relevante en la Base de Conocimiento. "
            f"Indica que no tienes información suficiente para responder con certeza."
        )

    try:
        answer = llm_client.generate(prompt, system_prompt=SYSTEM_PROMPT)
    except Exception as e:
        logger.exception("Error llamando al LLM")
        answer = "Ha habido un error generando la respuesta. Inténtalo de nuevo en un momento."

    await update.message.reply_text(answer)


async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "Hola, soy el asistente de la Base de Conocimiento. Pregúntame lo que necesites."
    )


def main():
    if not TELEGRAM_BOT_TOKEN:
        raise RuntimeError("Falta TELEGRAM_BOT_TOKEN en .env")

    # 1) Sincronizamos la BdC ANTES de aceptar preguntas (clona o pull inicial)
    sync_kb_once()

    # 2) Hilo en background para mantenerla actualizada mientras el bot vive
    if KB_REPO_URL:
        threading.Thread(target=pull_kb_loop, daemon=True).start()

    application = Application.builder().token(TELEGRAM_BOT_TOKEN).build()
    application.add_handler(CommandHandler("start", start_command))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

    logger.info("Bot arrancado. Esperando mensajes (polling)...")
    application.run_polling()


if __name__ == "__main__":
    main()
