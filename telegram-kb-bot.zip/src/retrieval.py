"""
Recuperación de contexto sobre la Base de Conocimiento (/kb).

Versión inicial deliberadamente simple: coincidencia de palabras clave
sobre los ficheros .md de la BdC. Es determinista, rápida y no añade
dependencias pesadas. Cuando la BdC crezca, esto se puede sustituir por
embeddings + búsqueda vectorial sin tocar bot.py (misma firma de función).
"""

import os
import re
from pathlib import Path

KB_PATH = Path(os.getenv("KB_PATH", "./kb"))
TOP_K = int(os.getenv("RETRIEVAL_TOP_K", "4"))


def _tokenize(text: str) -> set:
    return set(re.findall(r"\w+", text.lower()))


def _load_kb_files() -> list[tuple[str, str]]:
    """Devuelve [(ruta_relativa, contenido), ...] de todos los .md de /kb."""
    files = []
    if not KB_PATH.exists():
        return files
    for path in KB_PATH.rglob("*.md"):
        try:
            content = path.read_text(encoding="utf-8")
            files.append((str(path.relative_to(KB_PATH)), content))
        except Exception:
            continue
    return files


def get_relevant_context(question: str, top_k: int = TOP_K) -> str:
    """
    Devuelve un bloque de texto con los `top_k` fragmentos de /kb más
    relevantes para la pregunta, listos para meter en el prompt del LLM.
    """
    question_tokens = _tokenize(question)
    if not question_tokens:
        return ""

    scored = []
    for rel_path, content in _load_kb_files():
        content_tokens = _tokenize(content)
        overlap = len(question_tokens & content_tokens)
        if overlap > 0:
            scored.append((overlap, rel_path, content))

    scored.sort(key=lambda x: x[0], reverse=True)
    top = scored[:top_k]

    if not top:
        return ""

    blocks = [f"### Fuente: {rel_path}\n{content.strip()}" for _, rel_path, content in top]
    return "\n\n".join(blocks)
