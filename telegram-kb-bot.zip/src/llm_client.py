"""
Capa de abstracción del LLM.

El resto del bot solo conoce la función `generate(prompt)`. Quién responde
detrás (OpenAI, Anthropic, el LLM de la UGR...) se decide por variables de
entorno, así que cambiar de proveedor no requiere tocar bot.py ni retrieval.py.

Para añadir un proveedor nuevo: añade un bloque en `generate()` o, si tiene
una API tipo OpenAI (la mayoría de LLMs auto-hospedados la exponen así,
por ejemplo vía vLLM/Ollama/LM Studio), probablemente te valga la rama
"openai_compatible" sin escribir código nuevo.
"""

import os
import requests

LLM_PROVIDER = os.getenv("LLM_PROVIDER", "openai").lower()
LLM_BASE_URL = os.getenv("LLM_BASE_URL", "https://api.openai.com/v1")
LLM_API_KEY = os.getenv("LLM_API_KEY", "")
LLM_MODEL = os.getenv("LLM_MODEL", "gpt-4o-mini")


def generate(prompt: str, system_prompt: str = "") -> str:
    """Devuelve la respuesta del LLM configurado para un prompt dado."""
    if LLM_PROVIDER in ("openai", "ugr", "openai_compatible"):
        return _generate_openai_compatible(prompt, system_prompt)
    elif LLM_PROVIDER == "anthropic":
        return _generate_anthropic(prompt, system_prompt)
    else:
        raise ValueError(f"LLM_PROVIDER desconocido: {LLM_PROVIDER}")


def _generate_openai_compatible(prompt: str, system_prompt: str) -> str:
    """
    Sirve para OpenAI y para la mayoría de LLMs auto-hospedados/UGR,
    que suelen exponer un endpoint compatible con /v1/chat/completions.
    Si el endpoint de la UGR tiene un formato distinto, solo hay que
    adaptar esta función (o añadir una rama "ugr" propia).
    """
    url = f"{LLM_BASE_URL}/chat/completions"
    headers = {
        "Authorization": f"Bearer {LLM_API_KEY}",
        "Content-Type": "application/json",
    }
    messages = []
    if system_prompt:
        messages.append({"role": "system", "content": system_prompt})
    messages.append({"role": "user", "content": prompt})

    payload = {
        "model": LLM_MODEL,
        "messages": messages,
        "temperature": 0,
    }
    resp = requests.post(url, headers=headers, json=payload, timeout=60)
    resp.raise_for_status()
    data = resp.json()
    return data["choices"][0]["message"]["content"].strip()


def _generate_anthropic(prompt: str, system_prompt: str) -> str:
    url = f"{LLM_BASE_URL}/messages"
    headers = {
        "x-api-key": LLM_API_KEY,
        "anthropic-version": "2023-06-01",
        "Content-Type": "application/json",
    }
    payload = {
        "model": LLM_MODEL,
        "max_tokens": 1000,
        "system": system_prompt or "",
        "messages": [{"role": "user", "content": prompt}],
    }
    resp = requests.post(url, headers=headers, json=payload, timeout=60)
    resp.raise_for_status()
    data = resp.json()
    return "".join(block["text"] for block in data["content"] if block["type"] == "text").strip()
